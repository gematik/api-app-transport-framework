class ServiceIdentifier:
    def __init__(self, system: str, code: str, display: str):
        self.system = system
        self.code = code
        self.display = display
